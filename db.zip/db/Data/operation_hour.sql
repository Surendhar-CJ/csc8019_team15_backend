INSERT INTO csc8019_team15.operation_hour (day_of_week,opening_time,closing_time) VALUES
	 ('MONDAY','11:30:00','21:30:00'),
	 ('TUESDAY','11:30:00','21:30:00'),
	 ('WEDNESDAY','11:30:00','21:30:00'),
	 ('THURSDAY','11:30:00','21:30:00'),
	 ('FRIDAY','11:30:00','22:00:00'),
	 ('SATURDAY','11:30:00','22:00:00'),
	 ('SUNDAY','11:30:00','21:10:00'),
     
     
	 ('MONDAY','11:00:00','21:00:00'),
	 ('TUESDAY','11:00:00','21:00:00'),
	 ('WEDNESDAY','11:00:00','21:00:00'),
	 ('THURSDAY','11:00:00','22:00:00'),
	 ('FRIDAY','09:00:00','22:00:00'),
	 ('SATURDAY','09:00:00','22:00:00'),
	 ('SUNDAY','09:00:00','22:00:00');
     
     INSERT INTO csc8019_team15.operation_hour (day_of_week,opening_time,closing_time) VALUES
	 ('MONDAY','11:00:00','23:00:00'),
	 ('TUESDAY','11:00:00','21:00:00'),
	 ('WEDNESDAY','11:00:00','21:00:00'),
	 ('THURSDAY','11:00:00','23:59:59'),
	 ('FRIDAY','09:00:00','23:59:59'),
	 ('SATURDAY','09:00:00','23:59:59'),
	 ('SUNDAY','11:00:00','23:00:00'),
     
     
	 ('MONDAY','11:30:00','22:30:00'),
	 ('TUESDAY','11:30:00','22:30:00'),
	 ('WEDNESDAY','11:30:00','22:30:00'),
	 ('THURSDAY','11:30:00','22:30:00'),
	 ('FRIDAY','11:30:00','23:30:00'),
	 ('SATURDAY','11:30:00','23:30:00'),
	 ('SUNDAY','11:30:00','22:30:00');
     
     
     INSERT INTO csc8019_team15.operation_hour (day_of_week,opening_time,closing_time) VALUES
	 ('MONDAY','11:30:00','22:30:00'),
	 ('TUESDAY','11:30:00','23:59:59'),
	 ('WEDNESDAY','12:00:00','23:59:59'),
	 ('THURSDAY','12:00:00','23:59:59'),
	 ('FRIDAY','12:00:00','01:00:00'),
	 ('SATURDAY','12:00:00','01:00:00'),
	 ('SUNDAY','12:00:00','23:00:00'),
     
	 ('MONDAY','06:30:00','21:30:00'),
	 ('TUESDAY','06:30:00','21:30:00'),
	 ('WEDNESDAY','06:30:00','21:30:00'),
	 ('THURSDAY','06:30:00','21:30:00'),
	 ('FRIDAY','06:30:00','21:30:00'),
	 ('SATURDAY','06:30:00','21:30:00'),
	 ('SUNDAY','06:30:00','21:30:00');
     
     INSERT INTO csc8019_team15.operation_hour (day_of_week,opening_time,closing_time) VALUES
	 ('MONDAY','11:00:00','23:30:00'),
	 ('TUESDAY','11:00:00','23:30:00'),
	 ('WEDNESDAY','11:00:00','23:30:00'),
	 ('THURSDAY','11:00:00','00:30:00'),
	 ('FRIDAY','11:00:00','01:30:00'),
	 ('SATURDAY','10:00:00','01:30:00'),
	 ('SUNDAY','11:00:00','23:30:00'),
	 ('MONDAY','11:30:00','22:00:00');
INSERT INTO csc8019_team15.operation_hour (day_of_week,opening_time,closing_time) VALUES
	 ('TUESDAY','11:30:00','22:00:00'),
	 ('WEDNESDAY','11:30:00','22:00:00'),
	 ('THURSDAY','11:30:00','22:00:00'),
	 ('FRIDAY','11:30:00','22:00:00'),
	 ('SATURDAY','11:30:00','22:00:00'),
	 ('SUNDAY','11:30:00','22:00:00'),
	 ('MONDAY','12:00:00','22:00:00'),
	 ('TUESDAY','12:00:00','22:00:00'),
	 ('WEDNESDAY','12:00:00','22:00:00'),
	 ('THURSDAY','12:00:00','22:00:00');
INSERT INTO csc8019_team15.operation_hour (day_of_week,opening_time,closing_time) VALUES
	 ('FRIDAY','12:00:00','23:00:00'),
	 ('SATURDAY','12:00:00','23:00:00'),
	 ('SUNDAY','12:00:00','22:00:00'),
	 ('MONDAY','11:00:00','22:00:00'),
	 ('TUESDAY','11:00:00','22:00:00'),
	 ('WEDNESDAY','11:00:00','22:00:00'),
	 ('THURSDAY','11:00:00','22:00:00'),
	 ('FRIDAY','11:00:00','22:00:00'),
	 ('SATURDAY','11:00:00','22:00:00'),
	 ('SUNDAY','11:00:00','22:00:00');
INSERT INTO csc8019_team15.operation_hour (day_of_week,opening_time,closing_time) VALUES
	 ('MONDAY','11:00:00','22:00:00'),
	 ('TUESDAY','11:00:00','22:00:00'),
	 ('WEDNESDAY','11:00:00','22:00:00'),
	 ('THURSDAY','11:00:00','22:00:00'),
	 ('FRIDAY','11:00:00','22:00:00'),
	 ('SATURDAY','11:00:00','22:00:00'),
	 ('SUNDAY','11:00:00','22:00:00'),
	 ('MONDAY','13:00:00','22:00:00'),
	 ('TUESDAY','13:00:00','22:00:00'),
	 ('WEDNESDAY','13:00:00','22:00:00');
INSERT INTO csc8019_team15.operation_hour (day_of_week,opening_time,closing_time) VALUES
	 ('THURSDAY','13:00:00','22:00:00'),
	 ('FRIDAY','13:00:00','22:00:00'),
	 ('SATURDAY','13:00:00','22:00:00'),
	 ('SUNDAY','13:00:00','22:00:00'),
	 ('MONDAY','05:00:00','22:30:00'),
	 ('TUESDAY','05:00:00','22:30:00'),
	 ('WEDNESDAY','05:00:00','22:30:00'),
	 ('THURSDAY','05:00:00','22:30:00'),
	 ('FRIDAY','05:00:00','22:30:00'),
	 ('SATURDAY','05:00:00','23:30:00');
INSERT INTO csc8019_team15.operation_hour (day_of_week,opening_time,closing_time) VALUES
	 ('SUNDAY','05:00:00','23:30:00'),
	 ('MONDAY','05:30:00','23:00:00'),
	 ('TUESDAY','05:30:00','23:00:00'),
	 ('WEDNESDAY','05:30:00','23:00:00'),
	 ('THURSDAY','05:30:00','23:00:00'),
	 ('FRIDAY','05:30:00','23:00:00'),
	 ('SATURDAY','05:30:00','23:00:00'),
	 ('SUNDAY','05:30:00','23:00:00'),
	 ('MONDAY','12:00:00','22:00:00'),
	 ('TUESDAY','12:00:00','22:00:00');
INSERT INTO csc8019_team15.operation_hour (day_of_week,opening_time,closing_time) VALUES
	 ('WEDNESDAY','12:00:00','22:00:00'),
	 ('THURSDAY','12:00:00','22:00:00'),
	 ('FRIDAY','12:00:00','22:30:00'),
	 ('SATURDAY','12:00:00','22:30:00'),
	 ('SUNDAY','12:00:00','21:30:00'),
	 ('MONDAY','05:00:00','22:00:00'),
	 ('TUESDAY','05:00:00','22:00:00'),
	 ('WEDNESDAY','05:00:00','22:00:00'),
	 ('THURSDAY','05:00:00','22:00:00'),
	 ('FRIDAY','05:00:00','22:00:00');
INSERT INTO csc8019_team15.operation_hour (day_of_week,opening_time,closing_time) VALUES
	 ('SATURDAY','05:00:00','22:00:00'),
	 ('SUNDAY','05:00:00','22:00:00'),
	 ('MONDAY','12:00:00','22:30:00'),
	 ('TUESDAY','12:00:00','22:30:00'),
	 ('WEDNESDAY','12:00:00','22:30:00'),
	 ('THURSDAY','12:00:00','22:30:00'),
	 ('FRIDAY','12:00:00','22:30:00'),
	 ('SATURDAY','12:00:00','22:30:00'),
	 ('SUNDAY','12:00:00','22:30:00'),
	 ('MONDAY','11:30:00','22:00:00');
INSERT INTO csc8019_team15.operation_hour (day_of_week,opening_time,closing_time) VALUES
	 ('TUESDAY','11:30:00','22:00:00'),
	 ('WEDNESDAY','11:30:00','22:00:00'),
	 ('THURSDAY','11:30:00','23:00:00'),
	 ('FRIDAY','11:30:00','23:00:00'),
	 ('SATURDAY','11:30:00','23:00:00'),
	 ('SUNDAY','11:30:00','22:00:00'),
	 ('MONDAY','10:00:00','22:00:00'),
	 ('TUESDAY','10:00:00','22:00:00'),
	 ('WEDNESDAY','10:00:00','22:00:00'),
	 ('THURSDAY','10:00:00','22:00:00');
INSERT INTO csc8019_team15.operation_hour (day_of_week,opening_time,closing_time) VALUES
	 ('FRIDAY','10:00:00','22:00:00'),
	 ('SATURDAY','10:00:00','22:00:00'),
	 ('SUNDAY','10:00:00','22:00:00'),
	 ('MONDAY','11:00:00','21:00:00'),
	 ('TUESDAY','11:00:00','21:00:00'),
	 ('WEDNESDAY','11:00:00','21:00:00'),
	 ('THURSDAY','11:00:00','21:00:00'),
	 ('FRIDAY','11:00:00','23:00:00'),
	 ('SATURDAY','11:00:00','23:00:00'),
	 ('SUNDAY','11:00:00','21:00:00');
INSERT INTO csc8019_team15.operation_hour (day_of_week,opening_time,closing_time) VALUES
	 ('MONDAY','12:00:00','00:00:00'),
	 ('TUESDAY','12:00:00','00:00:00'),
	 ('WEDNESDAY','12:00:00','00:00:00'),
	 ('THURSDAY','12:00:00','00:00:00'),
	 ('FRIDAY','12:00:00','00:00:00'),
	 ('SATURDAY','12:00:00','00:00:00'),
	 ('SUNDAY','12:00:00','00:00:00'),
	 ('MONDAY','11:00:00','22:00:00'),
	 ('TUESDAY','11:00:00','20:00:00'),
	 ('WEDNESDAY','00:00:00','00:00:00');
INSERT INTO csc8019_team15.operation_hour (day_of_week,opening_time,closing_time) VALUES
	 ('THURSDAY','11:00:00','19:00:00'),
	 ('FRIDAY','11:00:00','22:00:00'),
	 ('SATURDAY','11:00:00','22:00:00'),
	 ('SUNDAY','11:00:00','21:00:00'),
	 ('MONDAY','11:00:00','23:30:00'),
	 ('TUESDAY','11:00:00','23:30:00'),
	 ('WEDNESDAY','11:00:00','23:30:00'),
	 ('THURSDAY','11:00:00','23:30:00'),
	 ('FRIDAY','11:00:00','23:30:00'),
	 ('SATURDAY','11:00:00','23:30:00');
INSERT INTO csc8019_team15.operation_hour (day_of_week,opening_time,closing_time) VALUES
	 ('SUNDAY','11:00:00','23:30:00'),
	 ('MONDAY','12:00:00','23:00:00'),
	 ('TUESDAY','12:00:00','23:00:00'),
	 ('WEDNESDAY','12:00:00','23:00:00'),
	 ('THURSDAY','12:00:00','23:00:00'),
	 ('FRIDAY','12:00:00','23:00:00'),
	 ('SATURDAY','12:00:00','23:00:00'),
	 ('SUNDAY','12:00:00','23:00:00'),
	 ('MONDAY','11:00:00','21:00:00'),
	 ('TUESDAY','11:00:00','21:00:00');
INSERT INTO csc8019_team15.operation_hour (day_of_week,opening_time,closing_time) VALUES
	 ('WEDNESDAY','11:00:00','21:00:00'),
	 ('THURSDAY','11:00:00','21:00:00'),
	 ('FRIDAY','11:00:00','21:00:00'),
	 ('SATURDAY','11:00:00','21:00:00'),
	 ('SUNDAY','11:00:00','21:00:00'),
	 ('MONDAY','11:00:00','21:30:00'),
	 ('TUESDAY','11:00:00','21:30:00'),
	 ('WEDNESDAY','11:00:00','21:30:00'),
	 ('THURSDAY','11:00:00','21:30:00'),
	 ('FRIDAY','11:00:00','22:30:00');
INSERT INTO csc8019_team15.operation_hour (day_of_week,opening_time,closing_time) VALUES
	 ('SATURDAY','11:00:00','22:30:00'),
	 ('SUNDAY','11:00:00','21:30:00'),
	 ('MONDAY','11:00:00','22:00:00'),
	 ('TUESDAY','11:00:00','22:00:00'),
	 ('WEDNESDAY','11:00:00','22:00:00'),
	 ('THURSDAY','11:00:00','22:00:00'),
	 ('FRIDAY','11:00:00','22:00:00'),
	 ('SATURDAY','11:00:00','22:00:00'),
	 ('SUNDAY','11:00:00','22:00:00'),
	 ('MONDAY','17:00:00','21:30:00');
INSERT INTO csc8019_team15.operation_hour (day_of_week,opening_time,closing_time) VALUES
	 ('TUESDAY','17:00:00','21:30:00'),
	 ('WEDNESDAY','17:00:00','21:30:00'),
	 ('THURSDAY','17:00:00','21:30:00'),
	 ('FRIDAY','17:00:00','21:30:00'),
	 ('SATURDAY','17:00:00','21:30:00'),
	 ('SUNDAY','17:00:00','21:30:00'),
	 ('MONDAY','09:00:00','22:00:00'),
	 ('TUESDAY','09:00:00','22:00:00'),
	 ('WEDNESDAY','09:00:00','22:00:00'),
	 ('THURSDAY','09:00:00','22:00:00');
INSERT INTO csc8019_team15.operation_hour (day_of_week,opening_time,closing_time) VALUES
	 ('FRIDAY','09:00:00','22:00:00'),
	 ('SATURDAY','09:00:00','22:00:00'),
	 ('SUNDAY','09:00:00','22:00:00'),
	 ('MONDAY','12:00:00','22:00:00'),
	 ('TUESDAY','12:00:00','22:00:00'),
	 ('WEDNESDAY','12:00:00','22:00:00'),
	 ('THURSDAY','12:00:00','22:00:00'),
	 ('FRIDAY','12:00:00','22:30:00'),
	 ('SATURDAY','12:00:00','22:30:00'),
	 ('SUNDAY','12:00:00','22:00:00');
