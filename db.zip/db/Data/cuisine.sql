INSERT INTO csc8019_team15.cuisine (name) VALUES
	 ('American'),
	 ('British'),
	 ('Caribbean'),
	 ('Chinese'),
	 ('Greek'),
	 ('Indian'),
	 ('Italian'),
	 ('Japanese'),
	 ('Korean'),
	 ('Mexican');
INSERT INTO csc8019_team15.cuisine (name) VALUES
	 ('Spanish'),
	 ('Thai'),
	 ('Turkish'),
	 ('Vietnamese');


